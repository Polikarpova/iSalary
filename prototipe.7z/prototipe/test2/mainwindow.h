#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <usergate.h>
#include <QMap>
#include <QHash>
#include <QSqlDatabase>
#include <QSqlError>
#include <QMessageBox>
#include <QTableWidget>
#include <QPushButton>
#include <cmath>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;

    void changeUser(int iCurRow, int iCurColumn, int iPrevRow, int iPrevColumn);
    void saveUser();
    void fillUsers();
    void deleteUser();
    void addUser();

    QTableWidget * _table;
    QHash<int, User> _users;
    UserGate * _userGate;
    QSqlDatabase  _db;

};

#endif // MAINWINDOW_H
