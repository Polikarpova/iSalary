#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    _table =  ui->tableWidget;


    auto drivers =  QSqlDatabase::drivers();
    QString mes = "";

    for ( auto s : drivers)
        mes += s + "\n";

    QMessageBox mesBox;
    mesBox.setText(mes);
    //mesBox.exec();

    ui->saveBtn->setEnabled(false);
    ui->removeBtn->setVisible(false);
    _db = QSqlDatabase::addDatabase("QMYSQL");


    _db.setHostName("127.0.0.1");
    _db.setPort(3306);
    _db.setDatabaseName("test");
    _db.setUserName("root");
    _db.setPassword("root");




    bool ok = _db.open();


    mesBox.setText( _db.lastError().text());
    if (!ok)
        mesBox.exec();

    _userGate = new UserGate(_db);
    _userGate->init();


    _table->clear();
    _table->setColumnCount( 4 );


    connect(_table, &QTableWidget::currentCellChanged, this, &MainWindow::changeUser);
    connect(ui->saveBtn, &QPushButton::clicked, this, &MainWindow::saveUser);
    connect(ui->removeBtn, &QPushButton::clicked, this, &MainWindow::deleteUser);
    connect(ui->addBtn, &QPushButton::clicked, this, &MainWindow::addUser);
    ui->calendarWidget->setSelectedDate(QDateTime::currentDateTime().date().addDays(3));
    QTextCharFormat format;
     QBrush brush;
     QColor color;
     int r=200,g=145,b=234,a=120;
     color.setRgb(r,g,b,a);;
     brush.setColor(color);
     format.setBackground(brush);
     QDate date = QDateTime::currentDateTime().date().addDays(-0);
     //ui->calendarWidget->setDateTextFormat(date,format);
     //ui->calendarWidget->setWeekdayTextFormat(Qt::DayOfWeek::Wednesday,format);


    fillUsers();
}


void  MainWindow::changeUser(int iCurRow, int iCurColumn, int iPrevRow, int iPrevColumn){
    if ( iCurRow != iPrevRow){
        //auto user = _users[ _table->item(iCurRow,0)->text().toInt() ];
        auto user = _userGate->getById(_table->item(iCurRow,0)->text().toInt() );
        ui ->idField->setText( QString::number(user.id));
        ui ->nameField->setText( user.name );
        ui ->dateField->setDateTime(user.date);
        ui ->salaryField->setText( QString::number(user.salary));
    }
    ui->saveBtn->setEnabled(true);
    ui->removeBtn->setVisible(true);
}

void  MainWindow::saveUser(){
    User user;
    user.id = ui->idField->text().length() ? ui->idField->text().toInt() : -1;
    user.name = ui->nameField->text();
    user.date = ui->dateField->dateTime();
    user.salary = ui->salaryField->text().toDouble();

    _userGate -> saveOrCreate(user);
    fillUsers();
}

void MainWindow::fillUsers(){
    auto users = _userGate -> getAll();
    _table->setRowCount( users.length());
    for ( auto iUser = users.begin(); iUser != users.end(); iUser++){
        _users.insert(iUser->id, *iUser);
        QTableWidgetItem * idItem = new QTableWidgetItem( QString::number(iUser->id));
        QTableWidgetItem * nameItem= new QTableWidgetItem( iUser->name);
        QTableWidgetItem * dateItem= new QTableWidgetItem( iUser->date.toString("dd.MM.yyyy"));
        QTableWidgetItem * salaryItem= new QTableWidgetItem( QString::number(iUser->salary));
        int row = iUser - users.begin();
        _table->setItem(row,0, idItem);
        _table->setItem(row,1, nameItem);
        _table->setItem(row,2, dateItem);
        _table->setItem(row,3, salaryItem);
    }

    double maxSalary = -1;
    QHash<QDate, double> sumByDate;
    for ( auto iUser = users.begin(); iUser != users.end(); iUser++){
        if ( !sumByDate.contains( iUser->date.date()) ){
            sumByDate[iUser->date.date()] = 0;
        }
        sumByDate[iUser->date.date()] += iUser->salary;
    }

    for (auto iDateSalary = sumByDate.begin(); iDateSalary != sumByDate.end(); iDateSalary++){
        maxSalary += iDateSalary.value();
    }

    QBrush brush;
    QColor color;

    int r = 255;
    int b = 255;
    int a = 255;
    for (auto iDateSalary = sumByDate.begin(); iDateSalary != sumByDate.end(); iDateSalary++){
        int g = 255 - ( 255 * iDateSalary.value()/ maxSalary);
        color.setRgb(r,g,b,a);
        QTextCharFormat format = ui->calendarWidget->dateTextFormat(iDateSalary.key());
        brush.setColor(color);
        format.setBackground(brush);
        ui->calendarWidget->setDateTextFormat(iDateSalary.key(),format);
    }
}

void MainWindow::deleteUser(){
    if ( ui->idField->text().length()){
        int id = ui->idField->text().toInt();
        _userGate->remove(id);
        QMessageBox::critical(this, "", _db.lastError().text());
        fillUsers();
    }
}

void MainWindow :: addUser(){
    ui->tableWidget->selectRow(-1);
    ui->idField->setText("");
    ui->nameField->setText("");
    ui->salaryField->setText("");
    ui->dateField->setDateTime(QDateTime::fromString("2000.01.01 12:00"));
    ui->removeBtn->setVisible(false);
    ui->saveBtn->setEnabled(true);
}

MainWindow::~MainWindow()
{
    delete ui;
}
