#ifndef USER_H
#define USER_H

#include <QString>
#include <QDate>

class User
{
public:
    User();
    int id;
    QString name;
    QDateTime date;
    double salary;
};

#endif // USER_H
