#ifndef USERGATE_H
#define USERGATE_H

#include <user.h>
#include <QVector>
#include <QSqlQuery>
#include <QSqlDatabase>
#include <QVariant>
#include <QSqlResult>

class UserGate
{
public:
    UserGate(QSqlDatabase &db);
    void init();
    QVector<User> getAll();
    User getById(int id);
    void saveOrCreate(User user);
    void remove(int id);
protected:
    const QString TABLE_NAME = "users";
    User read(const QSqlQuery * sqlQuery);
private:
    QSqlDatabase _db;

};


#endif // USERGATE_H
