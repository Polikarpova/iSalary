#include "usergate.h"


UserGate::UserGate(QSqlDatabase& db)
{
    _db = db;
}


User UserGate::read(const QSqlQuery * sqlQuery){
    User user;
    user.date = sqlQuery->value("date").value<QDateTime>();
    user.name = sqlQuery->value("name").value<QString>();
    user.id = sqlQuery->value("id").value<int>();
    user.salary = sqlQuery->value("salary").value<double>();
    return user;
}


QVector<User> UserGate::getAll(){
    QSqlQuery query(QString("SELECT * FROM ") + TABLE_NAME ,_db);

    QVector<User> users;
    while (query.next()){
        User user = read(&query);
        users.append(user);
    }
    return users;
}

User UserGate::getById(int id){
    QString sqlStr = QString("SELECT * FROM ") + TABLE_NAME + QString(" WHERE id = ") + QString::number(id);
    QSqlQuery query(sqlStr, _db);
    query.exec();
    bool isN = query.next();
    return read(&query);
}

void UserGate::saveOrCreate(User user){

    QSqlQuery query(_db);
    if ( user.id >= 1){
        query.prepare(QString("UPDATE users SET `name` = :name, `date` = :date, salary = :salary WHERE id = ") + QString::number(user.id));
    } else {
        query.prepare(QString("INSERT INTO users (`name`, `date`, `salary`) VALUES(:name, :date, :salary)" ));
    }
    query.bindValue(":name", user.name);
    query.bindValue(":date", user.date);
    query.bindValue(":salary", user.salary);

    bool isOk = query.exec();
    if (!isOk){
        int stop = 2;
    }

}

void UserGate::remove(int id){
    QSqlQuery query("DELETE FROM " + TABLE_NAME + " WHERE id = " + QString::number(id), _db);
    bool isOk = query.exec();

    return;
}

void UserGate::init(){
    QSqlQuery query(_db);
    query.prepare("CREATE TABLE  IF NOT EXISTS `users` (`id` int NOT NULL PRIMARY KEY AUTO_INCREMENT, `name` NVARCHAR(100) NOT NULL DEFAULT \'\',`date` datetime NOT NULL DEFAULT NOW(),`salary` double NOT NULL default 0)");
    query.exec();
}

